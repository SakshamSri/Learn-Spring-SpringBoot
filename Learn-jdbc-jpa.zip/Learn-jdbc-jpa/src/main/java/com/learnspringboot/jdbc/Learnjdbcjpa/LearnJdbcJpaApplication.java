package com.learnspringboot.jdbc.Learnjdbcjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearnJdbcJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearnJdbcJpaApplication.class, args);
	}

}
