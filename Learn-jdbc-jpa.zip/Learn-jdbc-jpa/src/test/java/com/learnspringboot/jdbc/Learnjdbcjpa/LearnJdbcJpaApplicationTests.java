package com.learnspringboot.jdbc.Learnjdbcjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnJdbcJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
